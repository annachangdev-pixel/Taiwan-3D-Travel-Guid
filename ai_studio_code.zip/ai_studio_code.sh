# 1. 初始化 Git 本地儲存庫
git init

# 2. 將所有檔案加入暫存區
git add .

# 3. 建立首次提交 (Commit)
git commit -m "feat: Taiwan 3D Map with authentic attractions and weather tide info"

# 4. 將預設分支命名為 main
git branch -M main

# 5. 綁定您剛在 GitHub 建立的遠端儲存庫（請將 YOUR_USERNAME 與 REPO_NAME 替換成您的）
git remote add origin https://github.com/YOUR_USERNAME/taiwan-3d-map.git

# 6. 推送至 GitHub
git push -u origin main